/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC18F47J13
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/examples/i2c2_master_example.h"
#include <string.h>


#define ZERO 0x00
#define AT30TS74_ADDRESS 0x48
#define Angle_Address_1 0x0E
#define Angle_Address_2 0x0F
#define Slave_Address 0x36

uint8_t tempReading = ZERO;
uint16_t LDR_1_con;
uint16_t LDR_2_con;
uint16_t LDR_converted;
int LDR_diff;
uint8_t LDR_thresh = 100;
uint8_t LDR_dark = 100;

uint8_t  b[2] = {0x0,0x0};
int  data = 0x0;

uint8_t forward_tx = 0b11101111;
uint8_t stop_tx = 0b11101100;
uint8_t backward_tx = 0b11101101;
uint8_t motor_state;

uint8_t spi_rx;

double timer_ms = 0; 

void sendToSPI (uint8_t data);
void timer_callback(void);;

/*
                         Main application
 */
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
    
    SPI1_Open(SPI1_DEFAULT);
    CSN_SetHigh();

    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts
    // Use the following macros to:

    // Enable the Global Interrupts
     INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Enable the Peripheral Interrupts
     INTERRUPT_PeripheralInterruptEnable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    
    LED_1_SetLow();
    LED_2_SetLow();
    LED_3_SetLow();
    LED_4_SetLow();
    LED_5_SetLow();
    LED_6_SetLow();
    
    TMR1_StartTimer();
    TMR1_SetInterruptHandler(timer_callback);
    

    while (1)
    {
        // Add your application code
        
        LDR_1_con = ADC_GetConversion(LDR_1);
        LDR_2_con = ADC_GetConversion(LDR_2);
        
        LDR_diff = abs(LDR_1_con - LDR_2_con);        
        
        
       
        if (!(LDR_1_con < LDR_dark && LDR_2_con < LDR_dark) && LDR_diff > LDR_thresh)
        {
            if(LDR_1_con > LDR_2_con)
            {
                LED_1_SetHigh();
                LED_2_SetLow();
                LED_3_SetLow();
                motor_state = 0;
                sendToSPI(forward_tx);
            }
            if (LDR_1_con < LDR_2_con)
            {
                LED_1_SetLow();
                LED_2_SetLow();
                LED_3_SetHigh();
                motor_state = 2;
                sendToSPI(backward_tx);
            }
            
        }
        else
        {
            LED_1_SetLow();
            LED_2_SetHigh();
            LED_3_SetLow();
            motor_state = 1;
            sendToSPI(stop_tx);
        }
        
       
         
        
    }
}

void sendToSPI (uint8_t data) 
{
    CSN_SetLow();
    spi_rx = SPI1_ExchangeByte(data);
    CSN_SetHigh();
    __delay_ms(5);
}

void timer_callback(void)
{
    timer_ms++;
    
    if (timer_ms >= 100.0)
    {
        tempReading = I2C2_Read1ByteRegister( AT30TS74_ADDRESS, 0x0);
        b[0] = I2C2_Read1ByteRegister(Slave_Address, Angle_Address_1);
        b[1] = I2C2_Read1ByteRegister(Slave_Address, Angle_Address_2);

        data = b[0]<<8|b[1];
       
        printf("%i  %il", LDR_1_con, LDR_2_con);
        printf("%it", tempReading);
        printf("%ih", data);
        printf("%im", motor_state);
        
        timer_ms -= 100.0;
        LED_6_Toggle();
    }
}
/**
 End of File
*/